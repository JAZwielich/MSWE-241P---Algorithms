import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        AnagramSort sort = new AnagramSort();
        List<String> words = new ArrayList<>();
        words.add("mango");
        words.add("ngamo");
        words.add("taco");
        words.add("urritob");
        words.add("burrito");
        List<List<String>> groupOfGrams= new ArrayList<>();
        groupOfGrams = sort.groupAnagram(words);

        for(int i = 0; i < groupOfGrams.size(); i++){
            System.out.println(groupOfGrams.get(i));
        }
    }
}