import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Graph that uses a smaller test case
        Graph citys = new Graph();
        citys.readText("city_population.txt", "road_network.txt");
        System.out.println("Here is the shortest number of connections needed to get from Lancaster to San Marcos " +
                        citys.shortestPathConnections(citys.getCity("Lancaster"), citys.getCity("San Marcos")));
        System.out.println(" Total Number of islands: " + citys.numberOfIslands());
        int[] totalCitiesPerIsland = citys.populationOfIslands();
        System.out.println("Total number of cities: ");
        for (int i = 0; i < totalCitiesPerIsland.length; i++) {System.out.print(totalCitiesPerIsland[i] + ",");}

        /**
         // Graph that uses a smaller test case
        Graph citys = new Graph();
        citys.readText("city_populationCopy.txt", "road_networkCopy.txt");
        citys.printGraph();
        List<City> shortPath = citys.bfs(citys.getCity("Tomato"), citys.getCity("Orange"));
        System.out.println(citys.numberOfCities(citys.getCity("BMW")));
        System.out.println(citys.totalPopulation(citys.getCity("BMW")));
        System.out.println(citys.shortestPathConnections(citys.getCity("Toyota"), citys.getCity("Ford")));
        System.out.println(citys.numberOfIslands());
         */
    }
}